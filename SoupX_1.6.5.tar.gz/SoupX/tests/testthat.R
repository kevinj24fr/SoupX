library(testthat)
library(SoupX)

test_check("SoupX") 